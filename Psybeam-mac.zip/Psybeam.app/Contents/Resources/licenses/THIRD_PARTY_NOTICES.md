# Third-party notices

Psybeam's app carries the software below. Each one's own licence file is in the app beside this one
(`Psybeam.app/Contents/Resources/licenses/`), and in each project's source.

| What | Licence | Where its source is |
|---|---|---|
| **mGBA** 0.10.5 (its GBA core, built unchanged into `libfrcore.dylib` with Psybeam's small C layer, `frlg_spike/shim/frcore.c`) | Mozilla Public License 2.0 | https://github.com/mgba-emu/mgba |
| **Python** | Python Software Foundation License | https://www.python.org |
| **websockets** | BSD 3-Clause | https://github.com/python-websockets/websockets |
| **NumPy** (and the libraries it ships with, listed in its own licence file) | BSD 3-Clause | https://github.com/numpy/numpy |
| **pystray** | GNU Lesser General Public License 3.0 | https://github.com/moses-palmer/pystray |
| **Pillow** | MIT-CMU (HPND) | https://github.com/python-pillow/Pillow |
| **PyObjC** | MIT | https://github.com/ronaldoussoren/pyobjc |
| **six** | MIT | https://github.com/benjaminp/six |
| **certifi** (Mozilla's list of trusted certificates) | Mozilla Public License 2.0 | https://github.com/certifi/python-certifi |
| **pywebview** (the app's window) | BSD 3-Clause | https://github.com/r0x0r/pywebview |
| **Bottle** | MIT | https://github.com/bottlepy/bottle |
| **proxy_tools** | MIT | https://github.com/jtushman/proxy_tools |
| **typing_extensions** | Python Software Foundation License | https://github.com/python/typing_extensions |
| **aiortc** (guests' WebRTC connections: only its networking parts; its media side, and PyAV with it, aren't in the app) | BSD 3-Clause | https://github.com/aiortc/aiortc |
| **aioice** | BSD 3-Clause | https://github.com/aiortc/aioice |
| **pylibsrtp** (and libsrtp, which it carries) | BSD 3-Clause | https://github.com/aiortc/pylibsrtp |
| **pyOpenSSL** | Apache License 2.0 | https://github.com/pyca/pyopenssl |
| **cryptography** (and OpenSSL, which it carries) | Apache License 2.0 or BSD 3-Clause (OpenSSL: Apache License 2.0) | https://github.com/pyca/cryptography |
| **cffi** | MIT-0 | https://github.com/python-cffi/cffi |
| **pycparser** | BSD 3-Clause | https://github.com/eliben/pycparser |
| **google-crc32c** | Apache License 2.0 | https://github.com/googleapis/python-crc32c |
| **pyee** | MIT | https://github.com/jfhbrook/pyee |
| **dnspython** | ISC | https://github.com/rthalley/dnspython |
| **ifaddr** | MIT | https://github.com/ifaddr/ifaddr |

**mGBA (MPL 2.0):** mGBA's source is at the address above. Psybeam uses version 0.10.5 as it is; the build options
are in `tools/build_frcore_mac.sh`.

**pystray (LGPL 3.0):** pystray is used unchanged, as its own Python package inside the app. You may replace it with
another version: its files are in `Psybeam.app/Contents/Resources/` (and its source is at the address above).

**Symbol table:** `pokefirered_rev1.sym` is a list of names and addresses produced by building the pret/pokefirered
disassembly project (https://github.com/pret/pokefirered). It contains no game code, graphics or text. Map and
trainer labels in `frapi/locations.py` come from the same project.

**Pokémon:** Pokémon and Pokémon FireRed are trademarks of Nintendo, Creatures and Game Freak. Psybeam isn't
affiliated with or endorsed by them, and includes none of their game: it runs on a copy of the game that its user
provides.
